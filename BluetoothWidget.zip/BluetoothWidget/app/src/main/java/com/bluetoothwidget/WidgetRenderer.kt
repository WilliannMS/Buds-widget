package com.bluetoothwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.view.View
import android.widget.RemoteViews

object WidgetRenderer {

    private const val SMALL = 0
    private const val MEDIUM = 1
    private const val LARGE = 2

    private const val BAR_W = 480
    private const val BAR_H = 48

    fun updateAll(context: Context) {
        val app = context.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        val ids = mgr.getAppWidgetIds(ComponentName(app, BluetoothWidgetProvider::class.java))
        if (ids.isEmpty()) return
        val prefs = Prefs(app)
        val state = prefs.state()
        for (id in ids) {
            try {
                mgr.updateAppWidget(id, build(app, mgr, id, prefs, state))
            } catch (t: Throwable) {
                // um widget com problema não derruba os outros
            }
        }
    }

    /** Tamanho atual do widget na tela, em dp. */
    private fun sizeDp(ctx: Context, mgr: AppWidgetManager, id: Int): Pair<Int, Int> {
        val o = mgr.getAppWidgetOptions(id)
        val minW = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        val minH = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
        val maxW = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
        val maxH = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var w = if (land) maxW else minW
        var h = if (land) minH else maxH
        if (w <= 0) w = 250
        if (h <= 0) h = 160
        return Pair(w, h)
    }

    private fun build(ctx: Context, mgr: AppWidgetManager, id: Int, prefs: Prefs, s: BtState): RemoteViews {
        val size = sizeDp(ctx, mgr, id)
        val wDp = size.first
        val hDp = size.second
        val density = ctx.resources.displayMetrics.density

        val layout = when (prefs.sizeMode) {
            1 -> SMALL
            2 -> MEDIUM
            3 -> LARGE
            else -> if (hDp < 140) SMALL else if (hDp < 200) MEDIUM else LARGE
        }
        val layoutRes = when (layout) {
            SMALL -> R.layout.widget_small
            LARGE -> R.layout.widget_large
            else -> R.layout.widget_medium
        }
        val rv = RemoteViews(ctx.packageName, layoutRes)

        // ----- fundo (cor, transparência, cantos, borda neon) -----
        var bw = (wDp * density).toInt().coerceAtLeast(100)
        var bh = (hDp * density).toInt().coerceAtLeast(60)
        val scale = minOf(1f, 720f / maxOf(bw, bh))
        bw = (bw * scale).toInt().coerceAtLeast(60)
        bh = (bh * scale).toInt().coerceAtLeast(40)
        rv.setImageViewBitmap(
            R.id.bg,
            Gfx.background(bw, bh, prefs.corner * density * scale, prefs.bgColor, prefs.bgAlpha, prefs.gradient, prefs.neonBorder)
        )

        // ----- textos -----
        rv.setTextViewText(R.id.title, s.name)
        val statusText = if (s.connected) "● Conectado" else "● Desconectado"
        rv.setTextColor(R.id.status, if (s.connected) Ui.GREEN else Ui.GRAY)
        rv.setTextViewText(
            R.id.status,
            if (layout == SMALL) statusText else statusText + "  ·  " + s.kind.label
        )

        // ----- imagem (foto dos fones ou ícone neon) -----
        val imgPx = when (layout) {
            SMALL -> 140
            else -> 260
        }
        setImage(rv, ctx, prefs, s, imgPx)

        // ----- baterias -----
        if (layout == SMALL) {
            val level = s.primary()
            setBar(rv, R.id.bar_1, R.id.pct_1, level, if (s.triple) (s.chargingLeft || s.chargingRight) else s.chargingMain)
            rv.setTextViewText(R.id.sub, subText(s, statusText))
        } else if (s.triple) {
            rv.setViewVisibility(R.id.row_2, View.VISIBLE)
            rv.setViewVisibility(R.id.row_3, View.VISIBLE)
            rv.setTextViewText(R.id.lbl_1, "E")
            rv.setTextViewText(R.id.lbl_2, "D")
            rv.setTextViewText(R.id.lbl_3, "Estojo")
            setBar(rv, R.id.bar_1, R.id.pct_1, s.left, s.chargingLeft)
            setBar(rv, R.id.bar_2, R.id.pct_2, s.right, s.chargingRight)
            setBar(rv, R.id.bar_3, R.id.pct_3, s.case, s.chargingCase)
        } else {
            rv.setViewVisibility(R.id.row_2, View.GONE)
            rv.setViewVisibility(R.id.row_3, View.GONE)
            rv.setTextViewText(R.id.lbl_1, "Bateria")
            setBar(rv, R.id.bar_1, R.id.pct_1, s.main, s.chargingMain)
        }

        // ----- toques: widget = atualizar, imagem = abrir o app -----
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val refresh = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, BluetoothWidgetProvider::class.java).setAction(BluetoothWidgetProvider.ACTION_REFRESH),
            flags
        )
        val open = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java), flags)
        rv.setOnClickPendingIntent(R.id.root, refresh)
        rv.setOnClickPendingIntent(R.id.img_frame, open)
        return rv
    }

    private fun subText(s: BtState, statusText: String): String {
        if (!s.connected) return "Desconectado"
        if (s.triple) {
            return "E " + pct(s.left) + "  ·  D " + pct(s.right) + "  ·  Estojo " + pct(s.case)
        }
        return statusText + "  ·  " + s.kind.label
    }

    private fun pct(level: Int): String = if (level < 0) "--" else level.toString() + "%"

    private fun setBar(rv: RemoteViews, barId: Int, pctId: Int, level: Int, charging: Boolean) {
        rv.setImageViewBitmap(barId, Gfx.neonBar(BAR_W, BAR_H, level, Ui.levelAccent(level)))
        rv.setTextViewText(pctId, Ui.pctText(level, charging))
        rv.setTextColor(pctId, Ui.levelText(level))
    }

    /**
     * Foto dos fones (opcional, só para fones) ou ícone neon do tipo do dispositivo.
     * Conectado + animação ligada: dois quadros alternando em fade (o brilho "respira").
     */
    private fun setImage(rv: RemoteViews, ctx: Context, prefs: Prefs, s: BtState, px: Int) {
        val photo = s.kind.hasPhoto && prefs.imageMode == 0
        val animate = s.connected && prefs.anim

        if (animate) {
            rv.setViewVisibility(R.id.flipper, View.VISIBLE)
            rv.setViewVisibility(R.id.img_static, View.GONE)
            if (photo) {
                rv.setImageViewResource(R.id.flip_a, R.drawable.case_a)
                rv.setImageViewResource(R.id.flip_b, R.drawable.case_b)
            } else {
                rv.setImageViewBitmap(R.id.flip_a, Gfx.neonIcon(ctx, s.kind.iconRes, px, 1))
                rv.setImageViewBitmap(R.id.flip_b, Gfx.neonIcon(ctx, s.kind.iconRes, px, 2))
            }
        } else {
            rv.setViewVisibility(R.id.flipper, View.GONE)
            rv.setViewVisibility(R.id.img_static, View.VISIBLE)
            if (photo) {
                rv.setImageViewResource(R.id.img_static, if (s.connected) R.drawable.case_a else R.drawable.case_off)
            } else {
                rv.setImageViewBitmap(
                    R.id.img_static,
                    Gfx.neonIcon(ctx, s.kind.iconRes, px, if (s.connected) 1 else 0)
                )
            }
        }
    }
}
