package com.bluetoothwidget

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.View

/** Barra de bateria neon usada na tela do app (mesmo desenho do widget). */
class NeonBarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var level: Int = 0
        set(value) {
            field = value
            invalidate()
        }

    var accent: Int = Ui.NEON
        set(value) {
            field = value
            invalidate()
        }

    init {
        // O brilho (blur) só funciona no desenho por software.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        Gfx.drawNeonBar(canvas, width.toFloat(), height.toFloat(), level, accent)
    }
}
