package com.bluetoothwidget

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private val running = mutableListOf<ValueAnimator>()
    private var last: ReadResult? = null
    private var iconKey = ""

    private val barIds = intArrayOf(R.id.bar_1, R.id.bar_2, R.id.bar_3)
    private val pctIds = intArrayOf(R.id.pct_1, R.id.pct_2, R.id.pct_3)
    private val lblIds = intArrayOf(R.id.lbl_1, R.id.lbl_2, R.id.lbl_3)
    private val rowIds = intArrayOf(R.id.row_1, R.id.row_2, R.id.row_3)

    private fun <T : View> find(id: Int): T = findViewById(id)

    private fun dpf(v: Int): Float = v * resources.displayMetrics.density
    private fun dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        styleTitle()
        startHeroAnimations()
        setupButtons()
        setupImageChoice()
        setupWidgetControls()
        setupDemo()

        render(ReadResult(emptyList(), prefs.state(), "Aguardando leitura…"))
    }

    override fun onResume() {
        super.onResume()
        refreshNow()
    }

    override fun onDestroy() {
        running.forEach { it.cancel() }
        running.clear()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshNow()
    }

    // ================================================================ visual

    private fun styleTitle() {
        val title = find<TextView>(R.id.app_title)
        title.post {
            val shader = LinearGradient(
                0f, 0f, title.width.toFloat().coerceAtLeast(1f), 0f,
                intArrayOf(0xFFFFFFFF.toInt(), 0xFFBFD0FF.toInt(), 0xFF9B8CFF.toInt()),
                null, Shader.TileMode.CLAMP
            )
            title.paint.shader = shader
            title.invalidate()
        }
    }

    private fun startHeroAnimations() {
        // Imagem flutuando de leve
        val frame = find<View>(R.id.prev_frame)
        val bob = ObjectAnimator.ofFloat(frame, "translationY", 0f, -dpf(6))
        bob.duration = 3200
        bob.repeatCount = ValueAnimator.INFINITE
        bob.repeatMode = ValueAnimator.REVERSE
        bob.interpolator = AccelerateDecelerateInterpolator()
        bob.start()
        running.add(bob)

        // Brilho "respirando"
        val glow = find<View>(R.id.prev_glow)
        val breathe = ObjectAnimator.ofFloat(glow, "alpha", 0f, 1f)
        breathe.duration = 1800
        breathe.repeatCount = ValueAnimator.INFINITE
        breathe.repeatMode = ValueAnimator.REVERSE
        breathe.interpolator = AccelerateDecelerateInterpolator()
        breathe.start()
        running.add(breathe)
    }

    // ================================================================ botões

    private fun setupButtons() {
        find<View>(R.id.btn_perm).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 7)
            }
        }
        find<View>(R.id.btn_refresh).setOnClickListener { refreshNow() }
        find<View>(R.id.btn_add).setOnClickListener { addWidget() }
    }

    private fun addWidget() {
        val manager = AppWidgetManager.getInstance(this)
        if (manager.isRequestPinAppWidgetSupported) {
            manager.requestPinAppWidget(ComponentName(this, BluetoothWidgetProvider::class.java), null, null)
        } else {
            toast("Segure um espaço vazio da tela inicial, toque em Widgets e escolha Bluetooth Widget")
        }
    }

    // ================================================================ foto x ícone

    private fun setupImageChoice() {
        drawImageChoice()
    }

    private fun drawImageChoice() {
        segmented(find(R.id.seg_image), listOf("Foto dos fones", "Ícone neon"), prefs.imageMode) { i ->
            prefs.imageMode = i
            iconKey = ""
            last?.let { render(it) }
            WidgetRenderer.updateAll(this)
        }
    }

    // ================================================================ widget

    private fun setupWidgetControls() {
        segmented(find(R.id.seg_size), listOf("Auto", "Compacto", "Médio", "Grande"), prefs.sizeMode) { i ->
            prefs.sizeMode = i
            WidgetRenderer.updateAll(this)
        }

        buildSwatches()

        val hue = find<SeekBar>(R.id.sb_hue)
        hue.max = 360
        hue.progress = 250
        onSeek(hue, { _ -> }) {
            prefs.bgColor = Color.HSVToColor(floatArrayOf(hue.progress.toFloat(), 0.65f, 0.38f))
            buildSwatches()
            onBackgroundChanged()
        }

        val alpha = find<SeekBar>(R.id.sb_alpha)
        alpha.max = 100
        alpha.progress = prefs.bgAlpha
        find<TextView>(R.id.tv_alpha).text = prefs.bgAlpha.toString() + "%"
        onSeek(alpha, { v ->
            prefs.bgAlpha = v
            find<TextView>(R.id.tv_alpha).text = v.toString() + "%"
            updateBgPreview()
        }) { onBackgroundChanged() }

        val corner = find<SeekBar>(R.id.sb_corner)
        corner.max = 44
        corner.progress = prefs.corner
        find<TextView>(R.id.tv_corner).text = prefs.corner.toString() + " dp"
        onSeek(corner, { v ->
            prefs.corner = v
            find<TextView>(R.id.tv_corner).text = v.toString() + " dp"
            updateBgPreview()
        }) { onBackgroundChanged() }

        val swGradient = find<Switch>(R.id.sw_gradient)
        swGradient.isChecked = prefs.gradient
        swGradient.setOnCheckedChangeListener { _, checked ->
            prefs.gradient = checked
            onBackgroundChanged()
        }

        val swBorder = find<Switch>(R.id.sw_border)
        swBorder.isChecked = prefs.neonBorder
        swBorder.setOnCheckedChangeListener { _, checked ->
            prefs.neonBorder = checked
            onBackgroundChanged()
        }

        val swAnim = find<Switch>(R.id.sw_anim)
        swAnim.isChecked = prefs.anim
        swAnim.setOnCheckedChangeListener { _, checked ->
            prefs.anim = checked
            WidgetRenderer.updateAll(this)
        }

        updateBgPreview()
    }

    private fun buildSwatches() {
        val box = find<LinearLayout>(R.id.swatches)
        box.removeAllViews()
        for (color in Ui.PRESETS) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams(dpi(40), dpi(40))
            lp.marginEnd = dpi(10)
            v.layoutParams = lp
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(color)
            val selected = color == prefs.bgColor
            d.setStroke(dpi(if (selected) 3 else 1), if (selected) Color.WHITE else 0x55FFFFFF)
            v.background = d
            v.setOnClickListener {
                prefs.bgColor = color
                buildSwatches()
                onBackgroundChanged()
            }
            box.addView(v)
        }
    }

    private fun onBackgroundChanged() {
        updateBgPreview()
        WidgetRenderer.updateAll(this)
    }

    /** Prévia instantânea do fundo (sem esperar o widget atualizar). */
    private fun updateBgPreview() {
        val a = prefs.bgAlpha * 255 / 100
        val c1 = Gfx.withAlpha(if (prefs.gradient) Gfx.gradStart(prefs.bgColor) else prefs.bgColor, a)
        val c2 = Gfx.withAlpha(if (prefs.gradient) Gfx.gradEnd(prefs.bgColor) else prefs.bgColor, a)
        val d = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
        d.cornerRadius = dpf(prefs.corner)
        if (prefs.neonBorder) d.setStroke(dpi(1), 0x77FFFFFF)
        find<View>(R.id.bg_preview).background = d
    }

    // ================================================================ demonstração

    private fun setupDemo() {
        val swDemo = find<Switch>(R.id.sw_demo)
        swDemo.isChecked = prefs.demo
        swDemo.setOnCheckedChangeListener { _, checked ->
            prefs.demo = checked
            refreshNow()
        }

        val swConn = find<Switch>(R.id.sw_conn)
        swConn.isChecked = prefs.demoConnected
        swConn.setOnCheckedChangeListener { _, checked ->
            prefs.demoConnected = checked
            refreshNow()
        }

        val swTriple = find<Switch>(R.id.sw_triple)
        swTriple.isChecked = prefs.demoTriple
        swTriple.setOnCheckedChangeListener { _, checked ->
            prefs.demoTriple = checked
            drawDemoSliders()
            refreshNow()
        }

        buildDemoKinds()
        drawDemoSliders()

        val sbE = find<SeekBar>(R.id.sb_e)
        val sbD = find<SeekBar>(R.id.sb_d)
        val sbC = find<SeekBar>(R.id.sb_c)
        val sbM = find<SeekBar>(R.id.sb_main)
        sbE.progress = prefs.demoLeft
        sbD.progress = prefs.demoRight
        sbC.progress = prefs.demoCase
        sbM.progress = prefs.demoMain
        onSeek(sbE, { v -> prefs.demoLeft = v; refreshNow() }) {}
        onSeek(sbD, { v -> prefs.demoRight = v; refreshNow() }) {}
        onSeek(sbC, { v -> prefs.demoCase = v; refreshNow() }) {}
        onSeek(sbM, { v -> prefs.demoMain = v; refreshNow() }) {}
    }

    /** Mostra os controles de E/D/Estojo ou o de bateria única, conforme o modo. */
    private fun drawDemoSliders() {
        val tri = prefs.demoTriple && DeviceKind.parse(prefs.demoKind).hasPhoto
        find<View>(R.id.demo_triple_box).visibility = if (tri) View.VISIBLE else View.GONE
        find<View>(R.id.demo_single_box).visibility = if (tri) View.GONE else View.VISIBLE
        find<View>(R.id.sw_triple).visibility =
            if (DeviceKind.parse(prefs.demoKind).hasPhoto) View.VISIBLE else View.GONE
    }

    private fun buildDemoKinds() {
        val box = find<LinearLayout>(R.id.demo_kinds)
        box.removeAllViews()
        for (kind in DeviceKind.values()) {
            val tv = TextView(this)
            val selected = kind.name == prefs.demoKind
            tv.text = kind.label
            tv.textSize = 13f
            tv.setPadding(dpi(14), dpi(8), dpi(14), dpi(8))
            tv.setTextColor(if (selected) Color.WHITE else Ui.GRAY)
            tv.setBackgroundResource(if (selected) R.drawable.seg_selected else R.drawable.chip_bg)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dpi(8)
            tv.layoutParams = lp
            tv.setOnClickListener {
                prefs.demoKind = kind.name
                buildDemoKinds()
                drawDemoSliders()
                refreshNow()
            }
            box.addView(tv)
        }
    }

    // ================================================================ componentes

    private fun segmented(container: LinearLayout, labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        container.removeAllViews()
        labels.forEachIndexed { i, label ->
            val tv = TextView(this)
            tv.text = label
            tv.gravity = Gravity.CENTER
            tv.textSize = 13f
            tv.setPadding(dpi(6), dpi(11), dpi(6), dpi(11))
            tv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val on = i == selected
            tv.setTextColor(if (on) Color.WHITE else Ui.GRAY)
            if (on) tv.setBackgroundResource(R.drawable.seg_selected)
            tv.setOnClickListener {
                onSelect(i)
                segmented(container, labels, i, onSelect)
            }
            container.addView(tv)
        }
    }

    private fun onSeek(bar: SeekBar, onChange: (Int) -> Unit, onStop: () -> Unit) {
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                onStop()
            }
        })
    }

    // ================================================================ leitura e desenho

    private fun refreshNow() {
        BluetoothWidgetProvider.refresh(applicationContext) { result ->
            if (!isFinishing && !isDestroyed) render(result)
        }
    }

    private fun render(res: ReadResult) {
        last = res
        val s = res.selected

        find<TextView>(R.id.prev_name).text = s.name
        find<TextView>(R.id.prev_kind).text = s.kind.label
        val status = find<TextView>(R.id.prev_status)
        status.text = if (s.connected) "● Conectado" else "● Desconectado"
        status.setTextColor(if (s.connected) Ui.GREEN else Ui.GRAY)

        // imagem do herói
        val photo = s.kind.hasPhoto && prefs.imageMode == 0
        val key = photo.toString() + "-" + s.kind.name + "-" + s.connected
        if (key != iconKey) {
            iconKey = key
            val base = find<ImageView>(R.id.prev_base)
            val glow = find<ImageView>(R.id.prev_glow)
            if (photo) {
                base.setImageResource(if (s.connected) R.drawable.case_a else R.drawable.case_off)
                glow.setImageResource(R.drawable.case_b)
            } else {
                base.setImageBitmap(Gfx.neonIcon(this, s.kind.iconRes, 420, if (s.connected) 1 else 0))
                glow.setImageBitmap(Gfx.neonIcon(this, s.kind.iconRes, 420, 2))
            }
        }
        find<View>(R.id.prev_glow).visibility = if (s.connected) View.VISIBLE else View.INVISIBLE

        // escolha foto x ícone: só aparece para fones
        find<View>(R.id.seg_image_box).visibility = if (s.kind.hasPhoto) View.VISIBLE else View.GONE

        // baterias
        if (s.triple) {
            find<View>(R.id.row_2).visibility = View.VISIBLE
            find<View>(R.id.row_3).visibility = View.VISIBLE
            find<TextView>(R.id.lbl_1).text = "E"
            find<TextView>(R.id.lbl_2).text = "D"
            find<TextView>(R.id.lbl_3).text = "Estojo"
            animateRow(0, s.left, s.chargingLeft)
            animateRow(1, s.right, s.chargingRight)
            animateRow(2, s.case, s.chargingCase)
        } else {
            find<View>(R.id.row_2).visibility = View.GONE
            find<View>(R.id.row_3).visibility = View.GONE
            find<TextView>(R.id.lbl_1).text = "Bateria"
            animateRow(0, s.main, s.chargingMain)
        }

        renderDevices(res)
        find<TextView>(R.id.diag).text = "Fonte dos dados: " + s.source
        find<View>(R.id.btn_perm).visibility = if (BtReader.hasPermission(this)) View.GONE else View.VISIBLE
    }

    private fun animateRow(index: Int, level: Int, charging: Boolean) {
        val bar = find<NeonBarView>(barIds[index])
        val pct = find<TextView>(pctIds[index])
        pct.setTextColor(Ui.levelText(level))
        bar.accent = Ui.levelAccent(level)
        val target = if (level < 0) 0 else level
        val animator = ValueAnimator.ofInt(bar.level, target)
        animator.duration = 900
        animator.addUpdateListener {
            val v = it.animatedValue as Int
            bar.level = v
            pct.text = if (level < 0) "--%" else (if (charging) "⚡" else "") + v + "%"
        }
        animator.start()
    }

    // ================================================================ lista de dispositivos

    private fun renderDevices(res: ReadResult) {
        val box = find<LinearLayout>(R.id.devices_list)
        box.removeAllViews()

        addDeviceRow(
            box, null, "Automático", "Mostra o melhor dispositivo conectado",
            DeviceKind.GENERIC, prefs.address == null
        )

        if (res.devices.isEmpty()) {
            val tv = TextView(this)
            tv.text = res.note
            tv.setTextColor(Ui.GRAY)
            tv.textSize = 13f
            tv.setPadding(dpi(4), dpi(10), dpi(4), dpi(4))
            box.addView(tv)
            return
        }
        for (d in res.devices) {
            addDeviceRow(box, d.address, d.name, d.kind.label + batteryText(d), d.kind, prefs.address == d.address)
        }
    }

    private fun batteryText(d: BtState): String {
        if (d.triple) {
            return "  ·  E " + pct(d.left) + "  D " + pct(d.right) + "  Estojo " + pct(d.case)
        }
        return if (d.main >= 0) "  ·  " + d.main + "%" else ""
    }

    private fun pct(level: Int): String = if (level < 0) "--" else level.toString() + "%"

    private fun addDeviceRow(
        box: LinearLayout, address: String?, name: String, sub: String,
        kind: DeviceKind, selected: Boolean
    ) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dpi(12), dpi(10), dpi(14), dpi(10))
        row.setBackgroundResource(if (selected) R.drawable.row_bg_selected else R.drawable.row_bg)
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = dpi(8)
        row.layoutParams = rlp

        val icon = ImageView(this)
        icon.layoutParams = LinearLayout.LayoutParams(dpi(44), dpi(44))
        icon.setImageBitmap(Gfx.neonIcon(this, kind.iconRes, 132, 1))
        row.addView(icon)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val clp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        clp.marginStart = dpi(12)
        col.layoutParams = clp

        val t1 = TextView(this)
        t1.text = name
        t1.setTextColor(Ui.TEXT)
        t1.textSize = 15f
        t1.maxLines = 1
        col.addView(t1)

        val t2 = TextView(this)
        t2.text = sub
        t2.setTextColor(Ui.GRAY)
        t2.textSize = 12f
        col.addView(t2)
        row.addView(col)

        val mark = TextView(this)
        mark.text = if (selected) "●" else "○"
        mark.setTextColor(if (selected) Ui.NEON else Ui.GRAY)
        mark.textSize = 16f
        row.addView(mark)

        row.setOnClickListener {
            prefs.address = address
            prefs.chosenName = if (address == null) null else name
            prefs.chosenKind = if (address == null) null else kind.name
            iconKey = ""
            refreshNow()
        }
        box.addView(row)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
