package com.bluetoothwidget

import android.content.Context

/** Tipos de dispositivo. Cada um tem um ícone neon padrão. */
enum class DeviceKind(val label: String, val iconRes: Int, val hasPhoto: Boolean) {
    EARBUDS("Fones sem fio", R.drawable.ic_dev_earbuds, true),
    HEADPHONES("Fones de ouvido", R.drawable.ic_dev_headphones, true),
    SPEAKER("Caixa de som", R.drawable.ic_dev_speaker, false),
    GAMEPAD("Controle", R.drawable.ic_dev_gamepad, false),
    KEYBOARD("Teclado", R.drawable.ic_dev_keyboard, false),
    MOUSE("Mouse", R.drawable.ic_dev_mouse, false),
    WATCH("Relógio", R.drawable.ic_dev_watch, false),
    PHONE("Celular", R.drawable.ic_dev_phone, false),
    COMPUTER("Computador", R.drawable.ic_dev_computer, false),
    CAR("Carro", R.drawable.ic_dev_car, false),
    TV("TV", R.drawable.ic_dev_tv, false),
    MIC("Microfone", R.drawable.ic_dev_mic, false),
    GENERIC("Bluetooth", R.drawable.ic_dev_generic, false);

    companion object {
        fun parse(name: String?): DeviceKind =
            values().firstOrNull { it.name == name } ?: GENERIC
    }
}

/** Estado de um dispositivo. Nível -1 = desconhecido. */
data class BtState(
    val connected: Boolean,
    val kind: DeviceKind,
    val name: String,
    val address: String?,
    val main: Int,
    val left: Int,
    val right: Int,
    val case: Int,
    /** true = o dispositivo informa E, D e estojo separados. */
    val triple: Boolean,
    val chargingMain: Boolean,
    val chargingLeft: Boolean,
    val chargingRight: Boolean,
    val chargingCase: Boolean,
    val source: String
) {
    /** Valor de destaque: o menor entre E e D (fones com estojo) ou a bateria única. */
    fun primary(): Int {
        if (triple) {
            val known = listOf(left, right).filter { it >= 0 }
            return if (known.isEmpty()) -1 else known.min()
        }
        return main
    }

    companion object {
        fun off(
            reason: String,
            name: String = "Nenhum dispositivo",
            kind: DeviceKind = DeviceKind.GENERIC,
            address: String? = null
        ) = BtState(
            connected = false, kind = kind, name = name, address = address,
            main = -1, left = -1, right = -1, case = -1, triple = false,
            chargingMain = false, chargingLeft = false, chargingRight = false, chargingCase = false,
            source = reason
        )
    }
}

/** Resultado de uma leitura: todos os dispositivos conectados e o que será exibido. */
data class ReadResult(
    val devices: List<BtState>,
    val selected: BtState,
    val note: String
)

object Ui {
    const val NEON = 0xFFEAF6FF.toInt()
    const val TEXT = 0xFFF2F2F4.toInt()
    const val GRAY = 0xFF9A9AA2.toInt()
    const val GREEN = 0xFF34C759.toInt()
    const val AMBER = 0xFFFFB340.toInt()
    const val RED = 0xFFFF453A.toInt()

    /** Cor do brilho da barra: branco neon, âmbar ou vermelho quando a bateria está baixa. */
    fun levelAccent(level: Int): Int = when {
        level in 0..15 -> RED
        level in 16..30 -> AMBER
        else -> NEON
    }

    fun levelText(level: Int): Int = when {
        level < 0 -> GRAY
        level <= 15 -> RED
        level <= 30 -> AMBER
        else -> TEXT
    }

    fun pctText(level: Int, charging: Boolean): String =
        if (level < 0) "--%" else (if (charging) "⚡" else "") + level + "%"

    /** Cores de fundo prontas para o widget. */
    val PRESETS = intArrayOf(
        0xFF101014.toInt(),
        0xFF1B2A4A.toInt(),
        0xFF2B1B4A.toInt(),
        0xFF0F3B2E.toInt(),
        0xFF4A1B2B.toInt(),
        0xFF3A2A12.toInt(),
        0xFF123A44.toInt(),
        0xFF2A2A2E.toInt(),
        0xFFE9E9F0.toInt()
    )
}

/** Configurações do usuário e o último estado lido. */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("bluetooth_widget", Context.MODE_PRIVATE)

    // ----- dispositivo exibido -----
    var address: String?
        get() = sp.getString("address", null)
        set(v) { sp.edit().putString("address", v).apply() }

    var chosenName: String?
        get() = sp.getString("chosen_name", null)
        set(v) { sp.edit().putString("chosen_name", v).apply() }

    var chosenKind: String?
        get() = sp.getString("chosen_kind", null)
        set(v) { sp.edit().putString("chosen_kind", v).apply() }

    // ----- aparência -----
    /** 0 = foto dos fones, 1 = ícone neon (só vale para fones). */
    var imageMode: Int
        get() = sp.getInt("image_mode", 0)
        set(v) { sp.edit().putInt("image_mode", v).apply() }

    /** 0 = automático, 1 = compacto, 2 = médio, 3 = grande. */
    var sizeMode: Int
        get() = sp.getInt("size_mode", 0)
        set(v) { sp.edit().putInt("size_mode", v).apply() }

    var bgColor: Int
        get() = sp.getInt("bg_color", Ui.PRESETS[0])
        set(v) { sp.edit().putInt("bg_color", v).apply() }

    /** Opacidade do fundo em % (0 = invisível, 100 = sólido). */
    var bgAlpha: Int
        get() = sp.getInt("bg_alpha", 62)
        set(v) { sp.edit().putInt("bg_alpha", v).apply() }

    /** Raio dos cantos em dp. */
    var corner: Int
        get() = sp.getInt("corner", 26)
        set(v) { sp.edit().putInt("corner", v).apply() }

    var gradient: Boolean
        get() = sp.getBoolean("gradient", true)
        set(v) { sp.edit().putBoolean("gradient", v).apply() }

    var neonBorder: Boolean
        get() = sp.getBoolean("neon_border", true)
        set(v) { sp.edit().putBoolean("neon_border", v).apply() }

    var anim: Boolean
        get() = sp.getBoolean("anim", true)
        set(v) { sp.edit().putBoolean("anim", v).apply() }

    // ----- modo demonstração -----
    var demo: Boolean
        get() = sp.getBoolean("demo", false)
        set(v) { sp.edit().putBoolean("demo", v).apply() }

    var demoConnected: Boolean
        get() = sp.getBoolean("demo_conn", true)
        set(v) { sp.edit().putBoolean("demo_conn", v).apply() }

    var demoKind: String
        get() = sp.getString("demo_kind", DeviceKind.EARBUDS.name) ?: DeviceKind.EARBUDS.name
        set(v) { sp.edit().putString("demo_kind", v).apply() }

    var demoTriple: Boolean
        get() = sp.getBoolean("demo_triple", true)
        set(v) { sp.edit().putBoolean("demo_triple", v).apply() }

    var demoMain: Int
        get() = sp.getInt("demo_main", 76)
        set(v) { sp.edit().putInt("demo_main", v).apply() }

    var demoLeft: Int
        get() = sp.getInt("demo_l", 100)
        set(v) { sp.edit().putInt("demo_l", v).apply() }

    var demoRight: Int
        get() = sp.getInt("demo_r", 100)
        set(v) { sp.edit().putInt("demo_r", v).apply() }

    var demoCase: Int
        get() = sp.getInt("demo_c", 80)
        set(v) { sp.edit().putInt("demo_c", v).apply() }

    fun demoState(): BtState {
        val kind = DeviceKind.parse(demoKind)
        val name = if (kind == DeviceKind.EARBUDS) "Redmi Buds 6 Play" else kind.label
        val tri = demoTriple && kind.hasPhoto
        return BtState(
            connected = demoConnected, kind = kind, name = name, address = "demo",
            main = if (tri) -1 else demoMain,
            left = if (tri) demoLeft else -1,
            right = if (tri) demoRight else -1,
            case = if (tri) demoCase else -1,
            triple = tri,
            chargingMain = false, chargingLeft = false, chargingRight = false, chargingCase = false,
            source = "Modo demonstração (valores manuais)"
        )
    }

    // ----- último estado lido (o widget desenha a partir daqui) -----
    fun saveState(s: BtState) {
        sp.edit()
            .putBoolean("s_conn", s.connected)
            .putString("s_kind", s.kind.name)
            .putString("s_name", s.name)
            .putString("s_addr", s.address)
            .putInt("s_main", s.main)
            .putInt("s_l", s.left)
            .putInt("s_r", s.right)
            .putInt("s_c", s.case)
            .putBoolean("s_tri", s.triple)
            .putBoolean("s_cm", s.chargingMain)
            .putBoolean("s_cl", s.chargingLeft)
            .putBoolean("s_cr", s.chargingRight)
            .putBoolean("s_cc", s.chargingCase)
            .putString("s_src", s.source)
            .apply()
    }

    fun state(): BtState = BtState(
        connected = sp.getBoolean("s_conn", false),
        kind = DeviceKind.parse(sp.getString("s_kind", null)),
        name = sp.getString("s_name", null) ?: "Nenhum dispositivo",
        address = sp.getString("s_addr", null),
        main = sp.getInt("s_main", -1),
        left = sp.getInt("s_l", -1),
        right = sp.getInt("s_r", -1),
        case = sp.getInt("s_c", -1),
        triple = sp.getBoolean("s_tri", false),
        chargingMain = sp.getBoolean("s_cm", false),
        chargingLeft = sp.getBoolean("s_cl", false),
        chargingRight = sp.getBoolean("s_cr", false),
        chargingCase = sp.getBoolean("s_cc", false),
        source = sp.getString("s_src", null) ?: "Ainda não atualizou"
    )
}
