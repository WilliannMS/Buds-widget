package com.bluetoothwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader

/**
 * Desenhos feitos em código (fundo, barras neon e ícones neon).
 * O widget do Android não aceita brilho/blur nativo, então tudo isso vira imagem.
 */
object Gfx {

    private val GLOW = 0xFFCFE9FF.toInt()

    fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    fun lerp(a: Int, b: Int, t: Float): Int {
        fun mix(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.argb(
            mix(Color.alpha(a), Color.alpha(b)),
            mix(Color.red(a), Color.red(b)),
            mix(Color.green(a), Color.green(b)),
            mix(Color.blue(a), Color.blue(b))
        )
    }

    fun gradStart(color: Int): Int = lerp(color, Color.WHITE, 0.18f)
    fun gradEnd(color: Int): Int = lerp(color, Color.BLACK, 0.45f)

    // ---------------------------------------------------------------- barras

    fun neonBar(w: Int, h: Int, level: Int, accent: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        drawNeonBar(Canvas(bmp), w.toFloat(), h.toFloat(), level, accent)
        return bmp
    }

    /** Barra de bateria com núcleo branco, brilho suave e um ponto de luz na ponta. */
    fun drawNeonBar(c: Canvas, w: Float, h: Float, level: Int, accent: Int) {
        val thick = h * 0.30f
        val cy = h / 2f
        val left = h * 0.45f
        val right = w - h * 0.45f
        val top = cy - thick / 2f
        val bottom = cy + thick / 2f
        val r = thick / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // trilho
        p.color = 0x2EFFFFFF
        c.drawRoundRect(RectF(left, top, right, bottom), r, r, p)

        val pct = level.coerceIn(0, 100)
        if (pct == 0) return
        val fillRight = maxOf(left + thick, left + (right - left) * pct / 100f)
        val fill = RectF(left, top, fillRight, bottom)

        // brilho largo e brilho curto
        p.maskFilter = BlurMaskFilter(h * 0.28f, BlurMaskFilter.Blur.NORMAL)
        p.color = withAlpha(accent, 150)
        c.drawRoundRect(fill, r, r, p)
        p.maskFilter = BlurMaskFilter(h * 0.12f, BlurMaskFilter.Blur.NORMAL)
        p.color = withAlpha(accent, 210)
        c.drawRoundRect(fill, r, r, p)
        p.maskFilter = null

        // núcleo
        p.shader = LinearGradient(
            fill.left, 0f, fill.right, 0f,
            lerp(accent, Color.WHITE, 0.85f), lerp(accent, Color.WHITE, 0.55f),
            Shader.TileMode.CLAMP
        )
        c.drawRoundRect(fill, r, r, p)
        p.shader = null

        // ponto de luz na ponta
        p.color = Color.WHITE
        c.drawCircle(fill.right - r, cy, r * 0.9f, p)
    }

    // ---------------------------------------------------------------- fundo

    /**
     * Fundo do widget: cor, transparência, degradê opcional e borda neon.
     * Gerado já no formato (proporção) do widget, então os cantos não distorcem.
     */
    fun background(
        w: Int, h: Int, radius: Float, color: Int, alphaPct: Int,
        gradient: Boolean, border: Boolean
    ): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val a = alphaPct.coerceIn(0, 100) * 255 / 100
        val inset = maxOf(3f, w / 150f)
        val rect = RectF(inset, inset, w - inset, h - inset)
        val r = minOf(radius, rect.height() / 2f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        if (gradient) {
            p.shader = LinearGradient(
                0f, 0f, w.toFloat(), h.toFloat(),
                withAlpha(gradStart(color), a), withAlpha(gradEnd(color), a),
                Shader.TileMode.CLAMP
            )
        } else {
            p.color = withAlpha(color, a)
        }
        c.drawRoundRect(rect, r, r, p)
        p.shader = null

        if (border) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = maxOf(2f, w / 300f)
            p.maskFilter = BlurMaskFilter(maxOf(3f, w / 140f), BlurMaskFilter.Blur.NORMAL)
            p.color = 0x66EAF6FF
            c.drawRoundRect(rect, r, r, p)
            p.maskFilter = null
            p.strokeWidth = maxOf(1.2f, w / 520f)
            p.color = 0x70FFFFFF
            c.drawRoundRect(rect, r, r, p)
        }
        return bmp
    }

    // ---------------------------------------------------------------- ícones

    /**
     * Ícone com efeito neon.
     * mode: 0 = apagado (desconectado), 1 = brilho fraco, 2 = brilho forte.
     */
    fun neonIcon(ctx: Context, resId: Int, size: Int, mode: Int): Bitmap {
        val d = ctx.getDrawable(resId)!!.mutate()
        val base = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val pad = (size * 0.14f).toInt()
        d.setBounds(pad, pad, size - pad, size - pad)
        d.draw(Canvas(base))

        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val off = IntArray(2)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val wideAlpha = when (mode) { 2 -> 230; 1 -> 130; else -> 40 }
        val tightAlpha = when (mode) { 2 -> 255; 1 -> 200; else -> 60 }

        val blurWide = Paint()
        blurWide.maskFilter = BlurMaskFilter(size * 0.075f, BlurMaskFilter.Blur.NORMAL)
        val wide = base.extractAlpha(blurWide, off)
        paint.color = withAlpha(GLOW, wideAlpha)
        c.drawBitmap(wide, off[0].toFloat(), off[1].toFloat(), paint)

        val blurTight = Paint()
        blurTight.maskFilter = BlurMaskFilter(size * 0.025f, BlurMaskFilter.Blur.NORMAL)
        val tight = base.extractAlpha(blurTight, off)
        paint.color = withAlpha(GLOW, tightAlpha)
        c.drawBitmap(tight, off[0].toFloat(), off[1].toFloat(), paint)

        val body = Paint(Paint.ANTI_ALIAS_FLAG)
        body.alpha = if (mode == 0) 110 else 255
        c.drawBitmap(base, 0f, 0f, body)
        return out
    }
}
