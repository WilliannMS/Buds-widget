package com.bluetoothwidget

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper

/**
 * Descobre os dispositivos Bluetooth conectados e lê a bateria de cada um.
 *
 * Bateria, em ordem de tentativa:
 *  1. Metadados do sistema (esquerdo, direito e estojo separados);
 *  2. Nível único de bateria do dispositivo.
 * Os dois usam reflexão (APIs escondidas do Android). Se o sistema bloquear, o app
 * continua funcionando e mostra o dispositivo sem a bateria.
 */
object BtReader {

    private const val PROXY_TIMEOUT_MS = 2500L

    // Metadados do Android (BluetoothDevice.METADATA_UNTETHERED_*)
    private const val KEY_LEFT_BATTERY = 10
    private const val KEY_RIGHT_BATTERY = 11
    private const val KEY_CASE_BATTERY = 12
    private const val KEY_LEFT_CHARGING = 13
    private const val KEY_RIGHT_CHARGING = 14
    private const val KEY_CASE_CHARGING = 15

    // BluetoothProfile.HID_HOST (constante escondida): controles, teclados e mouses
    private const val PROFILE_HID_HOST = 4

    fun hasPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    /** Chama [callback] na thread principal. */
    @SuppressLint("MissingPermission")
    fun readAll(context: Context, callback: (ReadResult) -> Unit) {
        val app = context.applicationContext
        val prefs = Prefs(app)

        if (prefs.demo) {
            val d = prefs.demoState()
            callback(ReadResult(listOf(d), d, "Modo demonstração"))
            return
        }

        fun empty(reason: String) {
            callback(ReadResult(emptyList(), select(emptyList(), prefs, reason), reason))
        }

        if (!hasPermission(app)) {
            empty("Falta a permissão de Bluetooth")
            return
        }
        val adapter: BluetoothAdapter? =
            (app.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            empty("Bluetooth desligado")
            return
        }

        collectConnected(app, adapter) { devices ->
            val states = devices.map { describe(it) }
            val note = if (states.isEmpty()) "Nenhum dispositivo conectado" else "Conectados: " + states.size
            callback(ReadResult(states, select(states, prefs, note), note))
        }
    }

    /** Escolhe o que aparece no widget: o dispositivo marcado ou o "melhor" conectado. */
    fun select(list: List<BtState>, prefs: Prefs, emptyReason: String): BtState {
        val wanted = prefs.address
        if (wanted != null) {
            return list.firstOrNull { it.address == wanted }
                ?: BtState.off(
                    "O dispositivo escolhido não está conectado",
                    prefs.chosenName ?: "Dispositivo",
                    DeviceKind.parse(prefs.chosenKind),
                    wanted
                )
        }
        if (list.isEmpty()) return BtState.off(emptyReason)
        return list.maxByOrNull { score(it) } ?: list.first()
    }

    private fun score(s: BtState): Int {
        var v = 0
        if (s.triple) v += 100 else if (s.main >= 0) v += 50
        v += when (s.kind) {
            DeviceKind.EARBUDS, DeviceKind.HEADPHONES -> 20
            DeviceKind.GAMEPAD, DeviceKind.SPEAKER -> 15
            DeviceKind.WATCH, DeviceKind.KEYBOARD, DeviceKind.MOUSE -> 10
            else -> 0
        }
        return v
    }

    // ------------------------------------------------------------ conectados

    @SuppressLint("MissingPermission")
    private fun collectConnected(
        app: Context,
        adapter: BluetoothAdapter,
        done: (List<BluetoothDevice>) -> Unit
    ) {
        val found = LinkedHashMap<String, BluetoothDevice>()
        var finished = false
        var pending = 0
        val handler = Handler(Looper.getMainLooper())

        fun complete() {
            if (finished) return
            finished = true
            // Complementos que não precisam de proxy
            try {
                for (d in adapter.bondedDevices) {
                    if (isConnectedReflect(d)) found[d.address] = d
                }
            } catch (t: Throwable) {
                // ignora
            }
            try {
                val mgr = app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                for (d in mgr.getConnectedDevices(BluetoothProfile.GATT)) found[d.address] = d
            } catch (t: Throwable) {
                // ignora
            }
            done(found.values.toList())
        }

        val profiles = intArrayOf(BluetoothProfile.HEADSET, BluetoothProfile.A2DP, PROFILE_HID_HOST)
        for (profile in profiles) {
            val listener = object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(p: Int, proxy: BluetoothProfile) {
                    try {
                        for (d in proxy.connectedDevices) found[d.address] = d
                    } catch (t: Throwable) {
                        // ignora
                    }
                    try {
                        adapter.closeProfileProxy(p, proxy)
                    } catch (t: Throwable) {
                        // ignora
                    }
                    pending--
                    if (pending <= 0) complete()
                }

                override fun onServiceDisconnected(p: Int) {}
            }
            val ok = try {
                adapter.getProfileProxy(app, listener, profile)
            } catch (t: Throwable) {
                false
            }
            if (ok) pending++
        }

        if (pending == 0) complete() else handler.postDelayed({ complete() }, PROXY_TIMEOUT_MS)
    }

    private fun isConnectedReflect(d: BluetoothDevice): Boolean = try {
        (BluetoothDevice::class.java.getMethod("isConnected").invoke(d) as? Boolean) ?: false
    } catch (t: Throwable) {
        false
    }

    // ------------------------------------------------------------ bateria

    @SuppressLint("MissingPermission")
    private fun nameOf(d: BluetoothDevice): String {
        val n: String? = try {
            if (Build.VERSION.SDK_INT >= 30) (d.alias ?: d.name) else d.name
        } catch (t: Throwable) {
            null
        }
        return n ?: d.address
    }

    @SuppressLint("MissingPermission")
    private fun describe(d: BluetoothDevice): BtState {
        val name = nameOf(d)
        val kind = DeviceClassifier.classify(d, name)

        val left = metaLevel(d, KEY_LEFT_BATTERY)
        val right = metaLevel(d, KEY_RIGHT_BATTERY)
        val case = metaLevel(d, KEY_CASE_BATTERY)
        if (left != null || right != null || case != null) {
            return BtState(
                connected = true, kind = kind, name = name, address = d.address,
                main = -1, left = left ?: -1, right = right ?: -1, case = case ?: -1,
                triple = true,
                chargingMain = false,
                chargingLeft = metaFlag(d, KEY_LEFT_CHARGING),
                chargingRight = metaFlag(d, KEY_RIGHT_CHARGING),
                chargingCase = metaFlag(d, KEY_CASE_CHARGING),
                source = "Metadados do sistema (E, D e estojo separados)"
            )
        }

        val single = singleLevel(d)
        val ok = single in 0..100
        return BtState(
            connected = true, kind = kind, name = name, address = d.address,
            main = if (ok) single else -1, left = -1, right = -1, case = -1,
            triple = false,
            chargingMain = false, chargingLeft = false, chargingRight = false, chargingCase = false,
            source = if (ok) "Nível de bateria informado pelo sistema" else "Este dispositivo não informa a bateria ao sistema"
        )
    }

    private fun metaBytes(d: BluetoothDevice, key: Int): ByteArray? = try {
        val m = BluetoothDevice::class.java.getMethod("getMetadata", Int::class.javaPrimitiveType)
        m.invoke(d, key) as? ByteArray
    } catch (t: Throwable) {
        null
    }

    private fun metaLevel(d: BluetoothDevice, key: Int): Int? {
        val bytes = metaBytes(d, key) ?: return null
        val value = String(bytes).trim().toIntOrNull() ?: return null
        return if (value in 0..100) value else null
    }

    private fun metaFlag(d: BluetoothDevice, key: Int): Boolean {
        val bytes = metaBytes(d, key) ?: return false
        val v = String(bytes).trim().lowercase()
        return v == "1" || v == "true"
    }

    private fun singleLevel(d: BluetoothDevice): Int = try {
        (BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(d) as? Int) ?: -1
    } catch (t: Throwable) {
        -1
    }
}
