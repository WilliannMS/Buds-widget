package com.bluetoothwidget

import android.annotation.SuppressLint
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice

/** Descobre o tipo do dispositivo pela classe Bluetooth e, se preciso, pelo nome. */
object DeviceClassifier {

    @SuppressLint("MissingPermission")
    fun classify(device: BluetoothDevice, name: String): DeviceKind {
        val byName = fromName(name)
        val cls: BluetoothClass? = try {
            device.bluetoothClass
        } catch (t: Throwable) {
            null
        }
        val byClass: DeviceKind? = if (cls != null) fromClass(cls) else null

        return when {
            byName == DeviceKind.EARBUDS -> DeviceKind.EARBUDS
            byClass != null && byClass != DeviceKind.GENERIC -> byClass
            byName != null -> byName
            else -> DeviceKind.GENERIC
        }
    }

    private fun fromClass(c: BluetoothClass): DeviceKind? {
        val cod = c.deviceClass
        return when (c.majorDeviceClass) {
            BluetoothClass.Device.Major.AUDIO_VIDEO -> when (cod) {
                BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET -> DeviceKind.EARBUDS
                BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE,
                BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES -> DeviceKind.HEADPHONES
                BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER,
                BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO,
                BluetoothClass.Device.AUDIO_VIDEO_HIFI_AUDIO -> DeviceKind.SPEAKER
                BluetoothClass.Device.AUDIO_VIDEO_MICROPHONE -> DeviceKind.MIC
                BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO -> DeviceKind.CAR
                BluetoothClass.Device.AUDIO_VIDEO_VIDEO_MONITOR,
                BluetoothClass.Device.AUDIO_VIDEO_VIDEO_DISPLAY_AND_LOUDSPEAKER,
                BluetoothClass.Device.AUDIO_VIDEO_SET_TOP_BOX -> DeviceKind.TV
                BluetoothClass.Device.AUDIO_VIDEO_VIDEO_GAMING_TOY -> DeviceKind.GAMEPAD
                else -> null
            }
            BluetoothClass.Device.Major.PERIPHERAL -> {
                val sub = cod and 0x3C
                val kb = cod and 0xC0
                when {
                    sub == 0x04 || sub == 0x08 -> DeviceKind.GAMEPAD
                    kb == 0x40 || kb == 0xC0 -> DeviceKind.KEYBOARD
                    kb == 0x80 -> DeviceKind.MOUSE
                    else -> null
                }
            }
            BluetoothClass.Device.Major.PHONE -> DeviceKind.PHONE
            BluetoothClass.Device.Major.COMPUTER -> DeviceKind.COMPUTER
            BluetoothClass.Device.Major.WEARABLE -> DeviceKind.WATCH
            BluetoothClass.Device.Major.TOY -> DeviceKind.GAMEPAD
            else -> null
        }
    }

    // ---------- pelo nome (dispositivos que não informam a classe) ----------

    private val earbuds = listOf("buds", "airpods", "pods", "earbuds", "tws", "earphone", "earpiece")
    private val gamepad = listOf(
        "controller", "gamepad", "dualsense", "dualshock", "xbox", "joy-con", "joycon",
        "gamesir", "8bitdo", "stadia", "controle"
    )
    private val mouse = listOf("mouse", "mx master", "mx anywhere", "m720", "m590")
    private val keyboard = listOf("keyboard", "teclado", "k380", "k780", "mx keys")
    private val headphones = listOf("headphone", "headset", "fone", "arctis", "momentum", "wh-1000")
    private val speaker = listOf("speaker", "soundbar", "caixa", "boombox", "partybox", "xtreme", "soundlink")
    private val watch = listOf("watch", "amazfit", "smartwatch", "mi band", "galaxy fit")
    private val tv = listOf("tv", "bravia", "roku", "chromecast")
    private val car = listOf("car", "carro")
    private val phone = listOf("iphone", "galaxy s", "pixel", "poco")
    private val mic = listOf("microphone", "microfone")

    private fun has(name: String, words: List<String>): Boolean =
        words.any { w ->
            if (w.length <= 3) {
                Regex("(^|[^a-z0-9])" + Regex.escape(w) + "($|[^a-z0-9])").containsMatchIn(name)
            } else {
                name.contains(w)
            }
        }

    private fun fromName(raw: String): DeviceKind? {
        val n = raw.lowercase()
        return when {
            has(n, earbuds) -> DeviceKind.EARBUDS
            has(n, gamepad) -> DeviceKind.GAMEPAD
            has(n, mouse) -> DeviceKind.MOUSE
            has(n, keyboard) -> DeviceKind.KEYBOARD
            has(n, headphones) -> DeviceKind.HEADPHONES
            has(n, speaker) -> DeviceKind.SPEAKER
            has(n, watch) -> DeviceKind.WATCH
            has(n, tv) -> DeviceKind.TV
            has(n, car) -> DeviceKind.CAR
            has(n, phone) -> DeviceKind.PHONE
            has(n, mic) -> DeviceKind.MIC
            else -> null
        }
    }
}
