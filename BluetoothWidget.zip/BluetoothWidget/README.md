# Bluetooth Widget

Widget de bateria para qualquer dispositivo Bluetooth (fones, controle, caixa de som, teclado, mouse, relógio...).

- Barras de bateria com brilho neon branco
- Ícone neon padrão por tipo de dispositivo
- Foto dos fones (com luz piscando) opcional, só para fones/earbuds
- Tamanho do conteúdo, cor, opacidade, cantos, degradê e borda neon configuráveis
- Modo demonstração para testar sem o dispositivo

Build: `gradle assembleDebug` (Gradle 8.7, JDK 17, Android SDK 34).
Chave de assinatura fixa (app/debug.keystore): novas versões atualizam por cima das antigas.
