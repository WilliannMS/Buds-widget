# Buds Widget

App Android com widget de tela inicial que mostra a bateria dos fones (esquerdo, direito e estojo),
usando a imagem do estojo dos Redmi Buds 6 Play.

- Widget com fundo semi-transparente (3 níveis, escolhidos no app) e LED que "respira" quando conectado.
- Toque no widget para atualizar; toque na imagem para abrir o app.
- O app mostra de onde veio a leitura de bateria ("Fonte dos dados") e tem um modo demonstração
  para testar o visual com valores manuais.

## Estrutura

- `app/src/main/java/com/budswidget/` — código em Kotlin (sem bibliotecas externas)
  - `BatteryReader.kt` — lê a bateria do fone conectado
  - `BudsWidgetProvider.kt` e `WidgetRenderer.kt` — o widget
  - `MainActivity.kt` — a tela do app, com a prévia animada
- `app/src/main/res/drawable-nodpi/case_*.png` — imagens do estojo (troque por outras mantendo os nomes)
- `app/src/main/res/layout/widget_buds.xml` — layout do widget

## Compilar

Com o Android Studio: abra a pasta e rode `assembleDebug`.
Com o GitHub Actions: veja o tutorial que acompanha este projeto.
