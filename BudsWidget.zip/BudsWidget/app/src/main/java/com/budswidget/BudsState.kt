package com.budswidget

import android.content.Context

/** Estado da bateria dos fones. Nível -1 = desconhecido. */
data class BudsState(
    val connected: Boolean,
    val left: Int,
    val right: Int,
    val case: Int,
    val chargingLeft: Boolean,
    val chargingRight: Boolean,
    val chargingCase: Boolean,
    val source: String,
    val deviceName: String?
) {
    companion object {
        fun off(reason: String) =
            BudsState(false, -1, -1, -1, false, false, false, reason, null)
    }
}

/** Cores compartilhadas entre o app e o widget. */
object Ui {
    const val GREEN = 0xFF34C759.toInt()
    const val GRAY = 0xFF9A9AA2.toInt()
    const val WHITE = 0xFFF2F2F4.toInt()
    const val AMBER = 0xFFFFB340.toInt()
    const val RED = 0xFFFF453A.toInt()

    fun levelColor(level: Int): Int = when {
        level < 0 -> GRAY
        level <= 15 -> RED
        level <= 30 -> AMBER
        else -> WHITE
    }
}

/** Tudo que o app guarda (configurações + último estado lido). */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("buds_widget", Context.MODE_PRIVATE)

    var demo: Boolean
        get() = sp.getBoolean("demo", false)
        set(v) { sp.edit().putBoolean("demo", v).apply() }

    var demoConnected: Boolean
        get() = sp.getBoolean("demo_conn", true)
        set(v) { sp.edit().putBoolean("demo_conn", v).apply() }

    var demoLeft: Int
        get() = sp.getInt("demo_l", 100)
        set(v) { sp.edit().putInt("demo_l", v).apply() }

    var demoRight: Int
        get() = sp.getInt("demo_r", 100)
        set(v) { sp.edit().putInt("demo_r", v).apply() }

    var demoCase: Int
        get() = sp.getInt("demo_c", 80)
        set(v) { sp.edit().putInt("demo_c", v).apply() }

    /** Animação (brilho do LED) dentro do widget. */
    var widgetAnim: Boolean
        get() = sp.getBoolean("widget_anim", true)
        set(v) { sp.edit().putBoolean("widget_anim", v).apply() }

    /** 0 = mais transparente, 1 = média, 2 = mais sólida. */
    var opacity: Int
        get() = sp.getInt("opacity", 1)
        set(v) { sp.edit().putInt("opacity", v).apply() }

    /** Endereço do fone escolhido; null = automático. */
    var address: String?
        get() = sp.getString("address", null)
        set(v) { sp.edit().putString("address", v).apply() }

    fun demoState(): BudsState = BudsState(
        connected = demoConnected,
        left = demoLeft,
        right = demoRight,
        case = demoCase,
        chargingLeft = false,
        chargingRight = false,
        chargingCase = false,
        source = "Modo demonstração (valores manuais)",
        deviceName = "Redmi Buds 6 Play"
    )

    fun saveState(s: BudsState) {
        sp.edit()
            .putBoolean("s_conn", s.connected)
            .putInt("s_l", s.left)
            .putInt("s_r", s.right)
            .putInt("s_c", s.case)
            .putBoolean("s_cl", s.chargingLeft)
            .putBoolean("s_cr", s.chargingRight)
            .putBoolean("s_cc", s.chargingCase)
            .putString("s_src", s.source)
            .putString("s_name", s.deviceName)
            .apply()
    }

    fun state(): BudsState = BudsState(
        connected = sp.getBoolean("s_conn", false),
        left = sp.getInt("s_l", -1),
        right = sp.getInt("s_r", -1),
        case = sp.getInt("s_c", -1),
        chargingLeft = sp.getBoolean("s_cl", false),
        chargingRight = sp.getBoolean("s_cr", false),
        chargingCase = sp.getBoolean("s_cc", false),
        source = sp.getString("s_src", "Ainda não atualizou") ?: "Ainda não atualizou",
        deviceName = sp.getString("s_name", null)
    )
}
