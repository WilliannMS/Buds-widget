package com.budswidget

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper

/**
 * Lê a bateria dos fones conectados.
 *
 * Ordem de tentativa:
 *  1. Metadados do sistema (esquerdo, direito e estojo separados) — o que o Android
 *     expõe quando o fabricante/o sistema preenche essas informações.
 *  2. Nível único de bateria do dispositivo Bluetooth.
 *  3. Conectado, mas sem informação de bateria.
 *
 * Os métodos 1 e 2 usam reflexão (APIs escondidas do Android); se o sistema bloquear,
 * o app cai para o próximo método sem travar.
 */
object BatteryReader {

    private const val PROXY_TIMEOUT_MS = 2500L

    // Chaves de metadados do Android (BluetoothDevice.METADATA_UNTETHERED_*)
    private const val KEY_LEFT_BATTERY = 10
    private const val KEY_RIGHT_BATTERY = 11
    private const val KEY_CASE_BATTERY = 12
    private const val KEY_LEFT_CHARGING = 13
    private const val KEY_RIGHT_CHARGING = 14
    private const val KEY_CASE_CHARGING = 15

    fun hasPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    /** Chama [callback] na thread principal com o estado atual. */
    @SuppressLint("MissingPermission")
    fun read(context: Context, callback: (BudsState) -> Unit) {
        val app = context.applicationContext
        val prefs = Prefs(app)

        if (prefs.demo) {
            callback(prefs.demoState())
            return
        }
        if (!hasPermission(app)) {
            callback(BudsState.off("Falta a permissão de Bluetooth"))
            return
        }
        val adapter: BluetoothAdapter? =
            (app.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            callback(BudsState.off("Bluetooth desligado"))
            return
        }

        findConnected(app, adapter, BluetoothProfile.HEADSET) { first ->
            if (first != null) {
                callback(describe(first))
            } else {
                findConnected(app, adapter, BluetoothProfile.A2DP) { second ->
                    if (second != null) {
                        callback(describe(second))
                    } else {
                        callback(BudsState.off("Nenhum fone conectado"))
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun findConnected(
        app: Context,
        adapter: BluetoothAdapter,
        profile: Int,
        done: (BluetoothDevice?) -> Unit
    ) {
        var finished = false
        val handler = Handler(Looper.getMainLooper())

        fun finish(device: BluetoothDevice?) {
            if (finished) return
            finished = true
            done(device)
        }

        val listener = object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(p: Int, proxy: BluetoothProfile) {
                val list: List<BluetoothDevice> = try {
                    proxy.connectedDevices
                } catch (t: Throwable) {
                    emptyList()
                }
                val wanted = Prefs(app).address
                val device: BluetoothDevice? = if (wanted != null) {
                    list.firstOrNull { it.address == wanted }
                } else {
                    list.firstOrNull { d ->
                        val n = try { d.name } catch (t: Throwable) { null } ?: ""
                        n.contains("Buds", ignoreCase = true) || n.contains("Redmi", ignoreCase = true)
                    } ?: list.firstOrNull()
                }
                try {
                    adapter.closeProfileProxy(p, proxy)
                } catch (t: Throwable) {
                    // ignora
                }
                finish(device)
            }

            override fun onServiceDisconnected(p: Int) {}
        }

        val ok = try {
            adapter.getProfileProxy(app, listener, profile)
        } catch (t: Throwable) {
            false
        }
        if (!ok) {
            finish(null)
        } else {
            handler.postDelayed({ finish(null) }, PROXY_TIMEOUT_MS)
        }
    }

    @SuppressLint("MissingPermission")
    private fun describe(d: BluetoothDevice): BudsState {
        val name: String? = try { d.name } catch (t: Throwable) { null }

        val left = metaLevel(d, KEY_LEFT_BATTERY)
        val right = metaLevel(d, KEY_RIGHT_BATTERY)
        val case = metaLevel(d, KEY_CASE_BATTERY)
        if (left != null || right != null || case != null) {
            return BudsState(
                connected = true,
                left = left ?: -1,
                right = right ?: -1,
                case = case ?: -1,
                chargingLeft = metaFlag(d, KEY_LEFT_CHARGING),
                chargingRight = metaFlag(d, KEY_RIGHT_CHARGING),
                chargingCase = metaFlag(d, KEY_CASE_CHARGING),
                source = "Metadados do sistema (E, D e estojo separados)",
                deviceName = name
            )
        }

        val single = singleLevel(d)
        if (single in 0..100) {
            return BudsState(
                connected = true,
                left = single,
                right = single,
                case = -1,
                chargingLeft = false,
                chargingRight = false,
                chargingCase = false,
                source = "Nível único do sistema (E e D iguais, sem estojo)",
                deviceName = name
            )
        }

        return BudsState(
            connected = true,
            left = -1,
            right = -1,
            case = -1,
            chargingLeft = false,
            chargingRight = false,
            chargingCase = false,
            source = "Conectado, mas o sistema não informa a bateria. Use o modo demonstração.",
            deviceName = name
        )
    }

    private fun metaBytes(d: BluetoothDevice, key: Int): ByteArray? = try {
        val m = BluetoothDevice::class.java.getMethod("getMetadata", Int::class.javaPrimitiveType)
        m.invoke(d, key) as? ByteArray
    } catch (t: Throwable) {
        null
    }

    private fun metaLevel(d: BluetoothDevice, key: Int): Int? {
        val bytes = metaBytes(d, key) ?: return null
        val value = String(bytes).trim().toIntOrNull() ?: return null
        return if (value in 0..100) value else null
    }

    private fun metaFlag(d: BluetoothDevice, key: Int): Boolean {
        val bytes = metaBytes(d, key) ?: return false
        val v = String(bytes).trim().lowercase()
        return v == "1" || v == "true"
    }

    private fun singleLevel(d: BluetoothDevice): Int = try {
        (BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(d) as? Int) ?: -1
    } catch (t: Throwable) {
        -1
    }
}
