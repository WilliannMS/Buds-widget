package com.budswidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

object WidgetRenderer {

    fun updateAll(context: Context) {
        val app = context.applicationContext
        val manager = AppWidgetManager.getInstance(app)
        val ids = manager.getAppWidgetIds(ComponentName(app, BudsWidgetProvider::class.java))
        if (ids.isEmpty()) return
        manager.updateAppWidget(ids, build(app))
    }

    private fun build(context: Context): RemoteViews {
        val prefs = Prefs(context)
        val s = prefs.state()
        val rv = RemoteViews(context.packageName, R.layout.widget_buds)

        // Fundo semi-transparente (3 níveis, escolhidos no app)
        val bg = when (prefs.opacity) {
            0 -> R.drawable.widget_bg_low
            2 -> R.drawable.widget_bg_high
            else -> R.drawable.widget_bg_mid
        }
        rv.setInt(R.id.root, "setBackgroundResource", bg)

        rv.setTextViewText(R.id.title, s.deviceName ?: "Redmi Buds 6 Play")
        rv.setTextViewText(R.id.status, if (s.connected) "● Conectado" else "● Desconectado")
        rv.setTextColor(R.id.status, if (s.connected) Ui.GREEN else Ui.GRAY)

        // Imagem: animada (LED respirando) só quando conectado e a animação estiver ligada
        if (s.connected && prefs.widgetAnim) {
            rv.setViewVisibility(R.id.flipper, View.VISIBLE)
            rv.setViewVisibility(R.id.img_static, View.GONE)
        } else {
            rv.setViewVisibility(R.id.flipper, View.GONE)
            rv.setViewVisibility(R.id.img_static, View.VISIBLE)
            rv.setImageViewResource(
                R.id.img_static,
                if (s.connected) R.drawable.case_a else R.drawable.case_off
            )
        }

        row(rv, R.id.bar_e, R.id.pct_e, s.left, s.chargingLeft)
        row(rv, R.id.bar_d, R.id.pct_d, s.right, s.chargingRight)
        row(rv, R.id.bar_c, R.id.pct_c, s.case, s.chargingCase)

        // Toque no widget = atualizar; toque na imagem = abrir o app
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val refresh = PendingIntent.getBroadcast(
            context, 0,
            Intent(context, BudsWidgetProvider::class.java).setAction(BudsWidgetProvider.ACTION_REFRESH),
            flags
        )
        val open = PendingIntent.getActivity(
            context, 1,
            Intent(context, MainActivity::class.java),
            flags
        )
        rv.setOnClickPendingIntent(R.id.root, refresh)
        rv.setOnClickPendingIntent(R.id.img_frame, open)
        return rv
    }

    private fun row(rv: RemoteViews, barId: Int, pctId: Int, level: Int, charging: Boolean) {
        rv.setProgressBar(barId, 100, if (level < 0) 0 else level, false)
        val text = if (level < 0) "--%" else (if (charging) "⚡" else "") + level + "%"
        rv.setTextViewText(pctId, text)
        rv.setTextColor(pctId, Ui.levelColor(level))
    }
}
