package com.budswidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

class BudsWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            AppWidgetManager.ACTION_APPWIDGET_UPDATE,
            ACTION_REFRESH,
            BluetoothDevice.ACTION_ACL_CONNECTED,
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                val pending = goAsync()
                // Ao conectar, o sistema leva alguns segundos para publicar a bateria.
                val delay = when (intent.action) {
                    BluetoothDevice.ACTION_ACL_CONNECTED -> 3000L
                    BluetoothDevice.ACTION_ACL_DISCONNECTED -> 1000L
                    else -> 0L
                }
                val app = context.applicationContext
                Handler(Looper.getMainLooper()).postDelayed({
                    refresh(app) { pending.finish() }
                }, delay)
            }
            else -> super.onReceive(context, intent)
        }
    }

    override fun onEnabled(context: Context) {
        WidgetRenderer.updateAll(context)
    }

    companion object {
        const val ACTION_REFRESH = "com.budswidget.REFRESH"

        /** Lê a bateria, salva, redesenha todos os widgets e avisa quando terminar. */
        fun refresh(context: Context, done: () -> Unit = {}) {
            val app = context.applicationContext
            BatteryReader.read(app) { state ->
                Prefs(app).saveState(state)
                WidgetRenderer.updateAll(app)
                done()
            }
        }
    }
}
