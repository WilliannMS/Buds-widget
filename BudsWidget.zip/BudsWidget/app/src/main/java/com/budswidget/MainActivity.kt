package com.budswidget

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private val running = mutableListOf<ValueAnimator>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        startPreviewAnimations()
        setupButtons()
        setupAppearance()
        setupDemo()
        render(prefs.state())
    }

    override fun onResume() {
        super.onResume()
        refreshNow()
    }

    override fun onDestroy() {
        running.forEach { it.cancel() }
        running.clear()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshNow()
    }

    // ---------- Animações da prévia ----------

    private fun startPreviewAnimations() {
        // Estojo flutuando de leve
        val frame = findViewById<View>(R.id.prev_frame)
        val float = ObjectAnimator.ofFloat(frame, "translationY", 0f, -dp(6))
        float.duration = 3200
        float.repeatCount = ValueAnimator.INFINITE
        float.repeatMode = ValueAnimator.REVERSE
        float.interpolator = AccelerateDecelerateInterpolator()
        float.start()
        running.add(float)

        // LED respirando
        val glow = findViewById<View>(R.id.prev_glow)
        val breathe = ObjectAnimator.ofFloat(glow, "alpha", 0f, 1f)
        breathe.duration = 1800
        breathe.repeatCount = ValueAnimator.INFINITE
        breathe.repeatMode = ValueAnimator.REVERSE
        breathe.interpolator = AccelerateDecelerateInterpolator()
        breathe.start()
        running.add(breathe)
    }

    private fun dp(v: Int): Float = v * resources.displayMetrics.density

    // ---------- Botões ----------

    private fun setupButtons() {
        findViewById<View>(R.id.btn_perm).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 7)
            }
        }
        findViewById<View>(R.id.btn_refresh).setOnClickListener { refreshNow() }
        findViewById<View>(R.id.btn_device).setOnClickListener { chooseDevice() }
        findViewById<View>(R.id.btn_add).setOnClickListener { addWidget() }
    }

    @SuppressLint("MissingPermission")
    private fun chooseDevice() {
        if (!BatteryReader.hasPermission(this)) {
            toast("Toque em \"Permitir Bluetooth\" primeiro")
            return
        }
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        val bonded = try { adapter?.bondedDevices?.toList() ?: emptyList() } catch (t: Throwable) { emptyList() }
        if (bonded.isEmpty()) {
            toast("Nenhum aparelho Bluetooth pareado")
            return
        }
        val names = mutableListOf("Automático (recomendado)")
        bonded.forEach { names.add(it.name ?: it.address) }
        AlertDialog.Builder(this)
            .setTitle("Escolher fones")
            .setItems(names.toTypedArray()) { _, which ->
                prefs.address = if (which == 0) null else bonded[which - 1].address
                refreshNow()
            }
            .show()
    }

    private fun addWidget() {
        val manager = AppWidgetManager.getInstance(this)
        if (manager.isRequestPinAppWidgetSupported) {
            manager.requestPinAppWidget(ComponentName(this, BudsWidgetProvider::class.java), null, null)
        } else {
            toast("Segure um espaço vazio da tela inicial > Widgets > Buds Widget")
        }
    }

    // ---------- Aparência do widget ----------

    private fun setupAppearance() {
        val swAnim = findViewById<Switch>(R.id.sw_anim)
        swAnim.isChecked = prefs.widgetAnim
        swAnim.setOnCheckedChangeListener { _, checked ->
            prefs.widgetAnim = checked
            WidgetRenderer.updateAll(this)
        }

        val group = findViewById<RadioGroup>(R.id.rg_opacity)
        group.check(
            when (prefs.opacity) {
                0 -> R.id.rb_low
                2 -> R.id.rb_high
                else -> R.id.rb_mid
            }
        )
        group.setOnCheckedChangeListener { _, id ->
            prefs.opacity = when (id) {
                R.id.rb_low -> 0
                R.id.rb_high -> 2
                else -> 1
            }
            WidgetRenderer.updateAll(this)
        }
    }

    // ---------- Modo demonstração ----------

    private fun setupDemo() {
        val swDemo = findViewById<Switch>(R.id.sw_demo)
        val swConn = findViewById<Switch>(R.id.sw_conn)
        val sbE = findViewById<SeekBar>(R.id.sb_e)
        val sbD = findViewById<SeekBar>(R.id.sb_d)
        val sbC = findViewById<SeekBar>(R.id.sb_c)

        swDemo.isChecked = prefs.demo
        swConn.isChecked = prefs.demoConnected
        sbE.progress = prefs.demoLeft
        sbD.progress = prefs.demoRight
        sbC.progress = prefs.demoCase

        swDemo.setOnCheckedChangeListener { _, checked ->
            prefs.demo = checked
            refreshNow()
        }
        swConn.setOnCheckedChangeListener { _, checked ->
            prefs.demoConnected = checked
            refreshNow()
        }
        onSeek(sbE) { prefs.demoLeft = it; refreshNow() }
        onSeek(sbD) { prefs.demoRight = it; refreshNow() }
        onSeek(sbC) { prefs.demoCase = it; refreshNow() }
    }

    private fun onSeek(bar: SeekBar, block: (Int) -> Unit) {
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) block(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
    }

    // ---------- Atualização e desenho ----------

    private fun refreshNow() {
        BudsWidgetProvider.refresh(applicationContext) {
            if (!isFinishing && !isDestroyed) render(Prefs(this).state())
        }
    }

    private fun render(s: BudsState) {
        findViewById<TextView>(R.id.prev_name).text = s.deviceName ?: "Redmi Buds 6 Play"

        val status = findViewById<TextView>(R.id.prev_status)
        status.text = if (s.connected) "● Conectado" else "● Desconectado"
        status.setTextColor(if (s.connected) Ui.GREEN else Ui.GRAY)

        findViewById<ImageView>(R.id.prev_base)
            .setImageResource(if (s.connected) R.drawable.case_a else R.drawable.case_off)
        findViewById<View>(R.id.prev_glow).visibility =
            if (s.connected) View.VISIBLE else View.INVISIBLE

        row(R.id.bar_e, R.id.pct_e, s.left, s.chargingLeft)
        row(R.id.bar_d, R.id.pct_d, s.right, s.chargingRight)
        row(R.id.bar_c, R.id.pct_c, s.case, s.chargingCase)

        findViewById<TextView>(R.id.diag).text = "Fonte dos dados: " + s.source
        findViewById<View>(R.id.btn_perm).visibility =
            if (BatteryReader.hasPermission(this)) View.GONE else View.VISIBLE
    }

    private fun row(barId: Int, pctId: Int, level: Int, charging: Boolean) {
        val bar = findViewById<ProgressBar>(barId)
        val pct = findViewById<TextView>(pctId)
        pct.setTextColor(Ui.levelColor(level))
        val target = if (level < 0) 0 else level
        val animator = ValueAnimator.ofInt(bar.progress, target)
        animator.duration = 900
        animator.addUpdateListener {
            val v = it.animatedValue as Int
            bar.progress = v
            pct.text = if (level < 0) "--%" else (if (charging) "⚡" else "") + v + "%"
        }
        animator.start()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
